@section('styles')

<link rel="stylesheet" type="text/css" href="{{asset('css/cars.css')}}">

@endsection
<div class="container-fluid">
  
    <div class="row">

    </div>
</div>
