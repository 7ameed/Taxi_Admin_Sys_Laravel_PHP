   
    <div class="panel panel-white " id="cars">
        <div class="panel-heading">
            <h4>احصائيات السيارات</h4></div>
        <div class="panel-body">
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-4">
                                    <i class="fa fa-taxi fa-4x"></i>
                                </div>
                                <div class="col-xs-8 text-right">
                                    <div class="huge">26</div>
                                    <div>السيارات النشطة</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-4">
                                    <i class="fa fa-wrench fa-4x"></i>
                                </div>
                                <div class="col-xs-8 text-right">
                                    <div class="huge">12</div>
                                    <div>السيارات فى الصيانة</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-4">
                                    <i class="fa fa-usd  fa-4x"></i>
                                </div>
                                <div class="col-xs-8 text-right">
                                    <div class="huge">124</div>
                                    <div>السيارات المباعة</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-4">
                                    <i class="fa fa-ban fa-4x"></i>
                                </div>
                                <div class="col-xs-8 text-right">
                                    <div class="huge">13</div>
                                    <div>السيارات المحذوفة </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="panel panel-white " id="money">
        <div class="panel-heading">
            <h4>أحصائيات مالية</h4></div>
        <div class="panel-body">
            <div class="row">
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-primary">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-4">
                                    <i class="fa fa-money fa-4x"></i>
                                </div>
                                <div class="col-xs-8 text-right">
                                    <div class="huge">26</div>
                                    <div>الدخل الشهري</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-yellow">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-4">
                                    <i class="fa fa-money fa-4x"></i>
                                </div>
                                <div class="col-xs-8 text-right">
                                    <div class="huge">2212</div>
                                    <div> الدخل الكلي</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-red">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-6 text-right">
                                    <div>صيانة</div>
                                    <div class="large">124</div>
                                </div>
                                <div class="col-xs-6 text-right">
                                    <div>مصروفات</div>
                                    <div class="large">124</div>
                                </div>
                                <div class="col-xs-8 text-right">
                                    <div>موظفين</div>
                                    <div class="large">124</div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="panel panel-green">
                        <div class="panel-heading">
                            <div class="row">
                                <div class="col-xs-4">
                                    <i class="fa fa-money fa-4x"></i>
                                </div>
                                <div class="col-xs-8 text-right">
                                    <div class="huge">1380</div>
                                    <div> الأرباح صافية </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="panel panel-white" id="branches">
        <div class="panel-heading">
            <h4>تفصيل الدخل من الفروع</h4></div>
        <div class="panel-body">
            <div class="panel panel-default ">
                <div class="panel-heading">
                    <h4 class="panel-title">
        <a data-toggle="collapse" href="#collapse1"><h4>اسم الفرع <small>4432</small></h4></a>
                    </h4>
                </div>
                <div id="collapse1" class="panel-collapse collapse">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-3 col-md-6">
                                <div class="panel panel-primary">
                                    <div class="panel-heading">
                                        <div class="row">
                                            <div class="col-xs-4">
                                                <i class="fa fa-money fa-4x"></i>
                                            </div>
                                            <div class="col-xs-8 text-right">
                                                <div class="huge">26</div>
                                                <div>الدخل الشهري</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="panel panel-yellow">
                                    <div class="panel-heading">
                                        <div class="row">
                                            <div class="col-xs-4">
                                                <i class="fa fa-money fa-4x"></i>
                                            </div>
                                            <div class="col-xs-8 text-right">
                                                <div class="huge">2212</div>
                                                <div> الدخل الكلي</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="panel panel-red">
                                    <div class="panel-heading">
                                        <div class="row">
                                            <div class="col-xs-6 text-right">
                                                <div>صيانة</div>
                                                <div class="large">124</div>
                                            </div>
                                            <div class="col-xs-6 text-right">
                                                <div>مصروفات</div>
                                                <div class="large">124</div>
                                            </div>
                                            <div class="col-xs-8 text-right">
                                                <div>موظفين</div>
                                                <div class="large">124</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="panel panel-green">
                                    <div class="panel-heading">
                                        <div class="row">
                                            <div class="col-xs-4">
                                                <i class="fa fa-money fa-4x"></i>
                                            </div>
                                            <div class="col-xs-8 text-right">
                                                <div class="huge">1380</div>
                                                <div> الأرباح صافية </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel panel-default">
                <div class="panel-heading">
                    <h4 class="panel-title">
        <a data-toggle="collapse" href="#collapse2"><h4>اسم الفرع <small>4432</small></h4></a>
                    </h4>
                </div>
                <div id="collapse2" class="panel-collapse collapse">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-3 col-md-6">
                                <div class="panel panel-primary">
                                    <div class="panel-heading">
                                        <div class="row">
                                            <div class="col-xs-4">
                                                <i class="fa fa-money fa-4x"></i>
                                            </div>
                                            <div class="col-xs-8 text-right">
                                                <div class="huge">26</div>
                                                <div>الدخل الشهري</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="panel panel-yellow">
                                    <div class="panel-heading">
                                        <div class="row">
                                            <div class="col-xs-4">
                                                <i class="fa fa-money fa-4x"></i>
                                            </div>
                                            <div class="col-xs-8 text-right">
                                                <div class="huge">2212</div>
                                                <div> الدخل الكلي</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="panel panel-red">
                                    <div class="panel-heading">
                                        <div class="row">
                                            <div class="col-xs-6 text-right">
                                                <div>صيانة</div>
                                                <div class="large">124</div>
                                            </div>
                                            <div class="col-xs-6 text-right">
                                                <div>مصروفات</div>
                                                <div class="large">124</div>
                                            </div>
                                            <div class="col-xs-8 text-right">
                                                <div>موظفين</div>
                                                <div class="large">124</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="panel panel-green">
                                    <div class="panel-heading">
                                        <div class="row">
                                            <div class="col-xs-4">
                                                <i class="fa fa-money fa-4x"></i>
                                            </div>
                                            <div class="col-xs-8 text-right">
                                                <div class="huge">1380</div>
                                                <div> الأرباح صافية </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="panel panel-default ">
                <div class="panel-heading">
                    <h4 class="panel-title">
        <a data-toggle="collapse" href="#collapse3"><h4>اسم الفرع <small>4432</small></h4></a>
                    </h4>
                </div>
                <div id="collapse3" class="panel-collapse collapse">
                    <div class="panel-body">
                        <div class="row">
                            <div class="col-lg-3 col-md-6">
                                <div class="panel panel-primary">
                                    <div class="panel-heading">
                                        <div class="row">
                                            <div class="col-xs-4">
                                                <i class="fa fa-money fa-4x"></i>
                                            </div>
                                            <div class="col-xs-8 text-right">
                                                <div class="huge">26</div>
                                                <div>الدخل الشهري</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="panel panel-yellow">
                                    <div class="panel-heading">
                                        <div class="row">
                                            <div class="col-xs-4">
                                                <i class="fa fa-money fa-4x"></i>
                                            </div>
                                            <div class="col-xs-8 text-right">
                                                <div class="huge">2212</div>
                                                <div> الدخل الكلي</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="panel panel-red">
                                    <div class="panel-heading">
                                        <div class="row">
                                            <div class="col-xs-6 text-right">
                                                <div>صيانة</div>
                                                <div class="large">124</div>
                                            </div>
                                            <div class="col-xs-6 text-right">
                                                <div>مصروفات</div>
                                                <div class="large">124</div>
                                            </div>
                                            <div class="col-xs-8 text-right">
                                                <div>موظفين</div>
                                                <div class="large">124</div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-6">
                                <div class="panel panel-green">
                                    <div class="panel-heading">
                                        <div class="row">
                                            <div class="col-xs-4">
                                                <i class="fa fa-money fa-4x"></i>
                                            </div>
                                            <div class="col-xs-8 text-right">
                                                <div class="huge">1380</div>
                                                <div> الأرباح صافية </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
