@extends('layouts.master')


@section('content')

@include('dashboard.'.$dep)

@endsection