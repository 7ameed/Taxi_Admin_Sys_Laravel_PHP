<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf8">
    <title>Taxi Management System</title>
    <link href="https://fonts.googleapis.com/css?family=Cairo|Changa" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.rawgit.com/morteza/bootstrap-rtl/v3.3.4/dist/css/bootstrap-rtl.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="{{asset('css/taxi.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('css/dashboard.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('css/aside.css')}}">

    @yield('styles')


</head>

<body dir="rtl">


    <div id="wrapper">
        <div class="overlay"></div>
    
        <!-- Sidebar -->
        <nav class="navbar navbar-inverse navbar-fixed-top" id="sidebar-wrapper" role="navigation">
            <ul class="nav sidebar-nav">
                <li class="sidebar-brand">
                    <a href="#">
                    <span class="glyphicon glyphicon-dashboard"></span>
                    <span>لوحة التحكم</span>
                </a>
                </li>
                <li @if($dep == 'overview') class="active" @endif>
                    <a href="{{url('dashboard/overview')}}">نظرة عامة</a>
                </li>
                <li @if($dep == 'cars') class="active" @endif>
                    <a href="{{url('dashboard/cars')}}">السيارات</a>
                </li>
                <li @if($dep == 'drivers') class="active" @endif>
                    <a href="{{url('dashboard/overview')}}">السائقين</a>
                </li>
                <li @if($dep == 'employers') class="active" @endif>
                    <a href="{{url('dashboard/overview')}}">الموظفين</a>
                </li>
                <!-- <li class="dropdown">
                  <a href="#" class="dropdown-toggle" data-toggle="dropdown">Works <span class="caret"></span></a>
                  <ul class="dropdown-menu" role="menu">
                    <li class="dropdown-header">Dropdown heading</li>
                    <li><a href="#">Action</a></li>
                    <li><a href="#">Another action</a></li>
                    <li><a href="#">Something else here</a></li>
                    <li><a href="#">Separated link</a></li>
                    <li><a href="#">One more separated link</a></li>
                  </ul>
                </li> -->
                <li @if($dep == 'maintenance') class="active" @endif>
                    <a href="#">الصيانة</a>
                </li>
                <li @if($dep == 'expenses') class="active" @endif>
                    <a href="#">المصروفات</a>
                </li>
                <li @if($dep == 'reports') class="active" @endif>
                    <a href="#">التقارير</a>
                </li>
                <li @if($dep == 'branches') class="active" @endif>
                    <a href="#">الفروع</a>
                </li>
            </ul>
        </nav>
        <!-- /#sidebar-wrapper -->

        <!-- Page Content -->
        <div id="page-content-wrapper">




    <nav>
        <ul class="nav-list">
            <li class="nav-item">
                <a href="#" class="nav-item">
                    <span class="glyphicon glyphicon-home"></span>
                    <span class="title-text">الرئيسية</span>

                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-item">
                    <span class="glyphicon glyphicon-user"></span>
                    <span class="title-text">الصفحة الشخصية</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-item hamburger is-closed" data-toggle="offcanvas">
                    <span class="glyphicon glyphicon-dashboard"></span>
                    <span class="title-text" >لوحة التحكم</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#" class="nav-item">
                    <span class="glyphicon glyphicon-off"></span>
                    <span class="title-text">خروج</span>
                </a>
            </li>
        </ul>
    </nav>

    <div class="subnav">
        <ul class="subnav-list">
            <li class="subnav-item">
                <a scroll-target="cars" class="subnav-item scrollto" data-toggle="tooltip" title="احصايات السيارات" data-placement="bottom">
                    <i class="fa fa-taxi fa-2x"></i>
                </a>
            </li>
            <li class="subnav-item">
                <a scroll-target="money" class="subnav-item scrollto" data-toggle="tooltip" title="احصايات مالية" data-placement="bottom">
                    <i class="fa fa-money fa-2x"></i>
                </a>
            </li>
            <li class="subnav-item">
                <a scroll-target="users"  class="subnav-item scrollto" data-toggle="tooltip" title="احصايات العاملين" data-placement="bottom">
                    <i class="fa fa-users fa-2x"></i>
                </a>
            </li>
            <li class="subnav-item">
                <a scroll-target="branches" class="subnav-item scrollto" data-toggle="tooltip" title="احصايات الفروع" data-placement="bottom">
                    <i class="fa fa-bar-chart fa-2x"></i>
                </a>
            </li>
            <li class="subnav-item">
                <a scroll-target="search" class="subnav-item scrollto" data-toggle="tooltip" title="ابحث عن سيارة , موظف .. الخ" data-placement="bottom">
                    <i class="fa fa-search fa-2x"></i>
                </a>
            </li>
        </ul>
        <hr>
    </div>

