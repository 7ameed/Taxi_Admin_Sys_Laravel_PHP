<!DOCTYPE html>
<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta charset="utf8">
    <title>Taxi Management System</title>
    <link href="https://fonts.googleapis.com/css?family=Cairo|Changa" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.rawgit.com/morteza/bootstrap-rtl/v3.3.4/dist/css/bootstrap-rtl.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" type="text/css" href="{{asset('css/taxi.css')}}">
    <link rel="stylesheet" type="text/css" href="{{asset('css/dashboard.css')}}">
</head>

<body dir="rtl">
    <nav>
        <ul class="nav-list">
            <li class="nav-item">
                <a href="#" class="nav-item">
                    <span class="glyphicon glyphicon-log-in"></span>
                    <span class="title-text">قم بالدخول لمباشرة العمل</span>

                </a>
            </li>
        </ul>
    </nav>

    <div class="login">
        <div class="panel panel-default">
         <div class="panel-heading">
                    <h4 class="panel-title">
                        دخول الادارة
                    </h4>
                </div>
  <div class="panel-body">
    <form class="form-horizontal">
    <br>
        <div class="form-group col-xs-12" >
            <label for="uname" class="col-xs-4">اسم المستخدم</label>
            <div class="col-xs-8">
                <input class="form-control" type="text" name="uname" id="uname" placeholder="اسم المستخدم">
        <br>
            </div>
        </div>
        <div class="form-group col-xs-12" >
            <label for="uname" class="col-xs-4">الرقم السرى</label>
            <div class="col-xs-8">
                <input class="form-control" type="password" name="uname" id="uname" placeholder="الرقم السرى">
            </div>
        </div>
        <div class="form-group col-xs-12" >

        <hr>
            <div class="col-xs-8 col-xs-offset-4">
                <a class="btn btn-danger" type="button" name="uname" id="uname" placeholder="اسم المستخدم">الدخول</a>
            </div>
        </div>
    </form>
        </div>
    </div>
</div>
</div>  
    </div>  


    <footer>
        
        <p class="text-center huge">2017 &copy;</p>
    </footer>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!-- Latest compiled JavaScript -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <script>
    $(document).ready(function() {
        $('[data-toggle="tooltip"]').tooltip();

        $(".scrollto").click(function() {
    $('html,body').animate({
        scrollTop: $('#'+$(this).attr('scroll-target')).offset().top},
        'slow');
});
    });
    </script>
</body>

</html>